#!/usr/bin/env python3
"""
Addmap

A script cli for insert a markmap inside index.md from your documentation, buid with mkdocs
"""

__version__ = (0, 1, 0)
__author__ = 'Xizuth'
__credits__ = 'Create and apped mindmap to render with markmap'

